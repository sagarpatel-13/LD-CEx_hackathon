import os
from typing import List, Optional
from fastapi import FastAPI, Depends, HTTPException, status, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy.orm import Session
from sqlalchemy import or_, desc

from database import engine, get_db, Base
import models
import schemas
from auth import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_user,
    get_optional_user
)
from seed_data import seed_database

# Create DB tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Travio API",
    description="Backend API and web server for Travio travel planning platform",
    version="2.0.0"
)

# Enable CORS for all origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Seed database on startup
@app.on_event("startup")
def on_startup():
    db = next(get_db())
    try:
        seed_database(db)
    finally:
        db.close()

# ================= AUTHENTICATION ENDPOINTS =================

@app.post("/api/auth/register", response_model=schemas.TokenResponse)
def register(user_data: schemas.UserRegister, db: Session = Depends(get_db)):
    existing = db.query(models.User).filter(models.User.email == user_data.email).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="An account with this email already exists."
        )

    new_user = models.User(
        email=user_data.email,
        password_hash=hash_password(user_data.password),
        first_name=user_data.first_name or "Travio",
        last_name=user_data.last_name or "User",
        phone=user_data.phone or "",
        city=user_data.city or "",
        country=user_data.country or "",
        bio=user_data.bio or "Passionate traveler exploring the world!",
        avatar_url=user_data.avatar_url or ""
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    token = create_access_token({"sub": str(new_user.id)})
    user_out = schemas.UserOut.from_orm(new_user)
    user_out.full_name = f"{new_user.first_name} {new_user.last_name}".strip()

    return schemas.TokenResponse(access_token=token, user=user_out)

@app.post("/api/auth/login", response_model=schemas.TokenResponse)
def login(login_data: schemas.UserLogin, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == login_data.email).first()
    if not user or not verify_password(login_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password."
        )

    token = create_access_token({"sub": str(user.id)})
    user_out = schemas.UserOut.from_orm(user)
    user_out.full_name = f"{user.first_name} {user.last_name}".strip()

    return schemas.TokenResponse(access_token=token, user=user_out)

@app.get("/api/auth/me", response_model=schemas.UserOut)
def get_me(current_user: models.User = Depends(get_current_user)):
    user_out = schemas.UserOut.from_orm(current_user)
    user_out.full_name = f"{current_user.first_name} {current_user.last_name}".strip()
    return user_out

@app.put("/api/auth/me", response_model=schemas.UserOut)
def update_profile(
    updates: schemas.UserUpdate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    if updates.first_name is not None:
        current_user.first_name = updates.first_name
    if updates.last_name is not None:
        current_user.last_name = updates.last_name
    if updates.phone is not None:
        current_user.phone = updates.phone
    if updates.city is not None:
        current_user.city = updates.city
    if updates.country is not None:
        current_user.country = updates.country
    if updates.bio is not None:
        current_user.bio = updates.bio
    if updates.avatar_url is not None:
        current_user.avatar_url = updates.avatar_url

    db.commit()
    db.refresh(current_user)

    user_out = schemas.UserOut.from_orm(current_user)
    user_out.full_name = f"{current_user.first_name} {current_user.last_name}".strip()
    return user_out

@app.post("/api/auth/avatar")
def update_avatar(
    data: schemas.AvatarUpdate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    current_user.avatar_url = data.avatar_url
    db.commit()
    return {"status": "success", "avatar_url": data.avatar_url}

@app.post("/api/auth/forgot-password")
def forgot_password(email: str):
    return {"message": f"Password reset instructions sent to {email}"}

# ================= TRIP ENDPOINTS =================

@app.get("/api/trips", response_model=List[schemas.TripOut])
def get_trips(
    status: Optional[str] = None,
    search: Optional[str] = None,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(models.Trip).filter(models.Trip.user_id == current_user.id)

    if status and status.lower() != "all":
        query = query.filter(models.Trip.status == status.lower())

    if search:
        search_pattern = f"%{search.lower()}%"
        query = query.filter(
            or_(
                models.Trip.name.ilike(search_pattern),
                models.Trip.destination.ilike(search_pattern),
                models.Trip.trip_type.ilike(search_pattern)
            )
        )

    trips = query.order_by(desc(models.Trip.created_at)).all()
    return trips

@app.post("/api/trips", response_model=schemas.TripOut, status_code=status.HTTP_201_CREATED)
def create_trip(
    trip_data: schemas.TripCreate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    image_map = {
        "switzerland": "https://images.unsplash.com/photo-1530789253388-582c481c54b0?auto=format&fit=crop&w=900&q=80",
        "paris": "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=900&q=80",
        "bali": "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80",
        "tokyo": "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=900&q=80",
        "japan": "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=900&q=80",
        "rome": "https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=900&q=80",
        "greece": "https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=900&q=80",
        "santorini": "https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=900&q=80",
        "thailand": "https://images.unsplash.com/photo-1528181304800-259b08848526?auto=format&fit=crop&w=900&q=80",
        "manali": "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=900&q=80",
        "jaipur": "https://images.unsplash.com/photo-1603287681856-960131c7d755?auto=format&fit=crop&w=800&q=80",
        "dubai": "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=900&q=80",
        "amsterdam": "https://images.unsplash.com/photo-1534351590666-13e3e96b5017?auto=format&fit=crop&w=900&q=80",
        "barcelona": "https://images.unsplash.com/photo-1583422409516-2895a77efded?auto=format&fit=crop&w=900&q=80"
    }

    img = trip_data.image_url
    if not img:
        dest_lower = trip_data.destination.lower()
        for key, url in image_map.items():
            if key in dest_lower:
                img = url
                break
        if not img:
            img = "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=900&q=80"

    new_trip = models.Trip(
        user_id=current_user.id,
        name=trip_data.name,
        destination=trip_data.destination,
        start_date=trip_data.start_date or "",
        end_date=trip_data.end_date or "",
        travellers=trip_data.travellers or 1,
        budget=trip_data.budget or 0.0,
        spent=trip_data.spent or 0.0,
        trip_type=trip_data.trip_type or "Adventure",
        status=trip_data.status or "upcoming",
        notes=trip_data.notes or "",
        image_url=img
    )
    db.add(new_trip)
    db.commit()
    db.refresh(new_trip)
    return new_trip

@app.get("/api/trips/{trip_id}", response_model=schemas.TripOut)
def get_trip(
    trip_id: int,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    trip = db.query(models.Trip).filter(models.Trip.id == trip_id, models.Trip.user_id == current_user.id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    return trip

@app.put("/api/trips/{trip_id}", response_model=schemas.TripOut)
def update_trip(
    trip_id: int,
    trip_data: schemas.TripUpdate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    trip = db.query(models.Trip).filter(models.Trip.id == trip_id, models.Trip.user_id == current_user.id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")

    for field, value in trip_data.dict(exclude_unset=True).items():
        setattr(trip, field, value)

    db.commit()
    db.refresh(trip)
    return trip

@app.delete("/api/trips/{trip_id}")
def delete_trip(
    trip_id: int,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    trip = db.query(models.Trip).filter(models.Trip.id == trip_id, models.Trip.user_id == current_user.id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")

    db.delete(trip)
    db.commit()
    return {"message": "Trip deleted successfully"}

# ================= ITINERARY ENDPOINTS =================

@app.get("/api/itinerary/stops", response_model=List[schemas.ItineraryStopOut])
def get_itinerary_stops(
    trip_id: Optional[int] = None,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(models.ItineraryStop).filter(models.ItineraryStop.user_id == current_user.id)
    if trip_id:
        query = query.filter(models.ItineraryStop.trip_id == trip_id)
    return query.order_by(models.ItineraryStop.order_index).all()

@app.post("/api/itinerary/stops", response_model=schemas.ItineraryStopOut)
def create_itinerary_stop(
    stop_data: schemas.ItineraryStopCreate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    city_images = {
        "Paris": "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=900&q=80",
        "Rome": "https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=900&q=80",
        "Amsterdam": "https://images.unsplash.com/photo-1534351590666-13e3e96b5017?auto=format&fit=crop&w=900&q=80",
        "Barcelona": "https://images.unsplash.com/photo-1583422409516-2895a77efded?auto=format&fit=crop&w=900&q=80",
        "London": "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=900&q=80",
        "Tokyo": "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=900&q=80",
        "Dubai": "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=900&q=80",
        "Singapore": "https://images.unsplash.com/photo-1525625293386-3f8f99389edd?auto=format&fit=crop&w=900&q=80"
    }

    count = db.query(models.ItineraryStop).filter(models.ItineraryStop.user_id == current_user.id).count()
    img = stop_data.image_url or city_images.get(stop_data.city, "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=900&q=80")

    new_stop = models.ItineraryStop(
        trip_id=stop_data.trip_id,
        user_id=current_user.id,
        day_number=stop_data.day_number or (count + 1),
        city=stop_data.city,
        country=stop_data.country or "",
        start_date=stop_data.start_date or "",
        end_date=stop_data.end_date or "",
        travel_mode=stop_data.travel_mode or "Flight",
        notes=stop_data.notes or "",
        order_index=count + 1,
        image_url=img
    )
    db.add(new_stop)
    db.commit()
    db.refresh(new_stop)
    return new_stop

@app.delete("/api/itinerary/stops/{stop_id}")
def delete_itinerary_stop(
    stop_id: int,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    stop = db.query(models.ItineraryStop).filter(
        models.ItineraryStop.id == stop_id,
        models.ItineraryStop.user_id == current_user.id
    ).first()
    if not stop:
        raise HTTPException(status_code=404, detail="Stop not found")
    db.delete(stop)
    db.commit()
    return {"message": "Stop removed successfully"}

@app.get("/api/itinerary/full")
def get_full_itinerary(
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    activities = db.query(models.ItineraryActivity).filter(
        models.ItineraryActivity.user_id == current_user.id
    ).order_by(models.ItineraryActivity.order_index).all()

    day1 = []
    day2 = []
    total_expense = 0.0

    for act in activities:
        item = {"activity": act.activity_name, "expense": act.expense, "category": act.category}
        total_expense += act.expense
        if act.day_number == 1:
            day1.append(item)
        else:
            day2.append(item)

    return {
        "destination_name": "Paris",
        "destination_country": "France",
        "budget": 15000.0,
        "total_expense": total_expense,
        "day1": day1,
        "day2": day2
    }

@app.post("/api/itinerary/save-full")
def save_full_itinerary(
    data: schemas.FullItinerarySave,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Clear existing activities for this user and recreate
    db.query(models.ItineraryActivity).filter(
        models.ItineraryActivity.user_id == current_user.id
    ).delete()

    idx = 1
    for item in data.day1:
        if item.activity.strip():
            db.add(models.ItineraryActivity(
                trip_id=data.trip_id,
                user_id=current_user.id,
                day_number=1,
                activity_name=item.activity.strip(),
                expense=item.expense or 0.0,
                category=item.category or "Activity",
                order_index=idx
            ))
            idx += 1

    idx = 1
    for item in data.day2:
        if item.activity.strip():
            db.add(models.ItineraryActivity(
                trip_id=data.trip_id,
                user_id=current_user.id,
                day_number=2,
                activity_name=item.activity.strip(),
                expense=item.expense or 0.0,
                category=item.category or "Activity",
                order_index=idx
            ))
            idx += 1

    db.commit()
    return {"message": "Itinerary saved successfully!", "status": "success"}

# ================= ACTIVITY ENDPOINTS =================

@app.get("/api/activities", response_model=List[schemas.ActivityOut])
def get_activities(
    city: Optional[str] = None,
    category: Optional[str] = None,
    search: Optional[str] = None,
    sort: Optional[str] = "default",
    db: Session = Depends(get_db)
):
    query = db.query(models.Activity)

    if city and city.lower() != "all":
        query = query.filter(models.Activity.city == city.lower())

    if category and category.lower() != "all":
        query = query.filter(models.Activity.category == category.lower())

    if search:
        search_pattern = f"%{search.lower()}%"
        query = query.filter(
            or_(
                models.Activity.title.ilike(search_pattern),
                models.Activity.description.ilike(search_pattern),
                models.Activity.location.ilike(search_pattern),
                models.Activity.city_name.ilike(search_pattern)
            )
        )

    if sort == "priceLow":
        query = query.order_by(models.Activity.price.asc())
    elif sort == "priceHigh":
        query = query.order_by(models.Activity.price.desc())
    elif sort == "rating":
        query = query.order_by(models.Activity.rating.desc())
    elif sort == "reviews":
        query = query.order_by(models.Activity.reviews.desc())
    else:
        query = query.order_by(models.Activity.is_featured.desc(), models.Activity.rating.desc())

    return query.all()

@app.get("/api/activities/featured", response_model=List[schemas.ActivityOut])
def get_featured_activities(db: Session = Depends(get_db)):
    return db.query(models.Activity).filter(models.Activity.is_featured == True).all()

# ================= DASHBOARD STATS ENDPOINT =================

@app.get("/api/dashboard/stats", response_model=schemas.DashboardStats)
def get_dashboard_stats(
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    trips = db.query(models.Trip).filter(models.Trip.user_id == current_user.id).all()

    total_trips = len(trips)
    upcoming_trips = sum(1 for t in trips if t.status == "upcoming")
    completed_trips = sum(1 for t in trips if t.status == "completed")
    planning_trips = sum(1 for t in trips if t.status == "planning")
    total_budget = sum(t.budget for t in trips)
    total_spent = sum(t.spent for t in trips)

    # Unique destinations/countries
    countries = set()
    for t in trips:
        if "," in t.destination:
            countries.add(t.destination.split(",")[-1].strip())
        else:
            countries.add(t.destination.strip())
    countries_visited = max(len(countries), 1 if total_trips > 0 else 0)

    return schemas.DashboardStats(
        total_trips=total_trips,
        upcoming_trips=upcoming_trips,
        completed_trips=completed_trips,
        planning_trips=planning_trips,
        countries_visited=countries_visited,
        total_budget=total_budget,
        total_spent=total_spent
    )

# ================= STATIC FILES & ROOT ROUTE =================

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

@app.get("/")
def serve_root():
    dashboard_path = os.path.join(CURRENT_DIR, "dashboard.html")
    if os.path.exists(dashboard_path):
        return FileResponse(dashboard_path)
    return {"message": "Welcome to Travio API"}

# Mount current directory for static files & html access
app.mount("/", StaticFiles(directory=CURRENT_DIR, html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    print("Starting Travio backend on http://127.0.0.1:8000 ...")
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
