import os
import sys
from fastapi.testclient import TestClient

from main import app
from database import SessionLocal
import models

client = TestClient(app)

def run_tests():
    print("========================================")
    print("   Running Travio Full Backend Tests    ")
    print("========================================")

    # 1. Test Demo Login
    res = client.post("/api/auth/login", json={"email": "demo@travio.com", "password": "password123"})
    assert res.status_code == 200, f"Login failed: {res.text}"
    token = res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("[PASS] 1. Demo User Login & JWT Token Generation")

    # 2. Test Get Current User (/api/auth/me)
    res = client.get("/api/auth/me", headers=headers)
    assert res.status_code == 200, f"Get user failed: {res.text}"
    user_info = res.json()
    assert user_info["email"] == "demo@travio.com"
    print(f"[PASS] 2. User Profile Retrieval: {user_info['full_name']} ({user_info['email']})")

    # 3. Test Registration with New User
    test_email = "new_explorer@travio.com"
    # Clean up if exists
    db = SessionLocal()
    existing = db.query(models.User).filter(models.User.email == test_email).first()
    if existing:
        db.delete(existing)
        db.commit()
    db.close()

    res = client.post("/api/auth/register", json={
        "email": test_email,
        "password": "securepassword",
        "first_name": "Alexander",
        "last_name": "Vagabond",
        "city": "Tokyo",
        "country": "Japan",
        "bio": "Traveling across continents!"
    })
    assert res.status_code == 200, f"Registration failed: {res.text}"
    new_token = res.json()["access_token"]
    new_headers = {"Authorization": f"Bearer {new_token}"}
    print(f"[PASS] 3. New User Registration & Immediate JWT Auth for {test_email}")

    # 4. Test Update User Profile
    res = client.put("/api/auth/me", json={"phone": "+1-555-0199", "bio": "Updated travel bio!"}, headers=new_headers)
    assert res.status_code == 200
    assert res.json()["phone"] == "+1-555-0199"
    print("[PASS] 4. User Profile Update")

    # 5. Test Trip Creation
    res = client.post("/api/trips", json={
        "name": "Nordic Lights Expedition",
        "destination": "Tromsø, Norway",
        "start_date": "2026-11-15",
        "end_date": "2026-11-22",
        "travellers": 2,
        "budget": 95000.0,
        "trip_type": "Adventure",
        "status": "upcoming",
        "notes": "Chasing auroras and dog sledding."
    }, headers=new_headers)
    assert res.status_code == 201, f"Trip creation failed: {res.text}"
    trip_id = res.json()["id"]
    print(f"[PASS] 5. Trip Creation: Trip #{trip_id} ('Nordic Lights Expedition')")

    # 6. Test Trips Retrieval
    res = client.get("/api/trips", headers=new_headers)
    assert res.status_code == 200
    trips = res.json()
    assert len(trips) == 1
    assert trips[0]["destination"] == "Tromsø, Norway"
    print(f"[PASS] 6. Trips Retrieval with User Scope: {len(trips)} trip found")

    # 7. Test Itinerary Stop Creation & Retrieval
    res = client.post("/api/itinerary/stops", json={
        "trip_id": trip_id,
        "city": "Oslo",
        "country": "Norway",
        "start_date": "2026-11-15",
        "end_date": "2026-11-17",
        "travel_mode": "Flight",
        "notes": "City exploration and Viking Ship Museum"
    }, headers=new_headers)
    assert res.status_code == 200
    stop_id = res.json()["id"]
    print(f"[PASS] 7. Itinerary Stop Creation: Stop #{stop_id} in Oslo")

    # 8. Test Itinerary Full Save (Day1 & Day2)
    res = client.post("/api/itinerary/save-full", json={
        "trip_id": trip_id,
        "destination_name": "Tromsø",
        "destination_country": "Norway",
        "budget": 95000.0,
        "day1": [
            {"activity": "Fjord Cable Car", "expense": 1800.0, "category": "sightseeing"},
            {"activity": "Northern Lights Tour", "expense": 5500.0, "category": "adventure"}
        ],
        "day2": [
            {"activity": "Whale Watching Safari", "expense": 6200.0, "category": "adventure"}
        ]
    }, headers=new_headers)
    assert res.status_code == 200
    print("[PASS] 8. Full Itinerary Day-Wise Activities and Expenses Saved")

    # 9. Test Activities Retrieval & Filtering
    res = client.get("/api/activities?city=ahmedabad")
    assert res.status_code == 200
    activities = res.json()
    assert len(activities) >= 1
    print(f"[PASS] 9. Curated Activities Search/Filter: Found {len(activities)} activities in Ahmedabad")

    # 10. Test Dashboard Statistics
    res = client.get("/api/dashboard/stats", headers=new_headers)
    assert res.status_code == 200
    stats = res.json()
    assert stats["total_trips"] == 1
    assert stats["upcoming_trips"] == 1
    assert stats["total_budget"] == 95000.0
    print(f"[PASS] 10. Dashboard Analytics: {stats['total_trips']} Trips, Budget: INR {stats['total_budget']}")

    # 11. Test Trip Deletion
    res = client.delete(f"/api/trips/{trip_id}", headers=new_headers)
    assert res.status_code == 200
    print(f"[PASS] 11. Trip Deletion: Trip #{trip_id} deleted")

    print("========================================")
    print("     ALL 11 BACKEND TESTS PASSED!       ")
    print("========================================")

if __name__ == "__main__":
    run_tests()
