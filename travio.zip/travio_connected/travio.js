/**
 * Travio Unified Frontend API Client & State Manager
 */
(function (window) {
  "use strict";

  // Determine API base URL
  const isHttp = window.location.protocol.startsWith("http");
  const defaultApiHost = isHttp && window.location.port === "8000" 
    ? window.location.origin 
    : "http://127.0.0.1:8000";

  const TravioAPI = {
    BASE_URL: defaultApiHost,

    getToken() {
      return localStorage.getItem("travio_token") || "";
    },

    setToken(token) {
      if (token) {
        localStorage.setItem("travio_token", token);
      } else {
        localStorage.removeItem("travio_token");
      }
    },

    getUser() {
      try {
        const raw = localStorage.getItem("loggedInUser") || localStorage.getItem("TraviosUser");
        return raw ? JSON.parse(raw) : null;
      } catch (e) {
        return null;
      }
    },

    setUser(user) {
      if (user) {
        const fullName = user.full_name || user.fullName || [user.first_name || user.firstName, user.last_name || user.lastName].filter(Boolean).join(" ") || "Travio Traveler";
        const normalized = {
          id: user.id || 1,
          email: user.email || "demo@travio.com",
          firstName: user.first_name || user.firstName || "Travio",
          lastName: user.last_name || user.lastName || "Traveler",
          fullName: fullName,
          phone: user.phone || "",
          city: user.city || "",
          country: user.country || "",
          bio: user.bio || "",
          avatarUrl: user.avatar_url || user.avatarUrl || user.profilePhoto || ""
        };
        localStorage.setItem("loggedInUser", JSON.stringify(normalized));
        localStorage.setItem("TraviosUser", JSON.stringify(normalized));
        this.displayUser(normalized);
        return normalized;
      } else {
        localStorage.removeItem("loggedInUser");
        localStorage.removeItem("TraviosUser");
      }
    },

    clearAuth() {
      this.setToken("");
      this.setUser(null);
    },

    logout() {
      this.clearAuth();
      this.showToast("Logged out successfully.", "info");
      setTimeout(() => {
        window.location.href = "login.html";
      }, 500);
    },

    async request(endpoint, options = {}) {
      const url = `${this.BASE_URL}${endpoint}`;
      const headers = {
        "Content-Type": "application/json",
        ...(options.headers || {})
      };

      const token = this.getToken();
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }

      try {
        const response = await fetch(url, { ...options, headers });
        const contentType = response.headers.get("content-type");
        let data = null;
        if (contentType && contentType.includes("application/json")) {
          data = await response.json();
        } else {
          data = await response.text();
        }

        if (!response.ok) {
          const message = (data && data.detail) || (data && data.message) || (typeof data === "string" ? data : "Request failed");
          throw new Error(message);
        }
        return data;
      } catch (err) {
        console.warn(`[TravioAPI] Network/API Error on ${endpoint}:`, err.message);
        throw err;
      }
    },

    // ================= AUTH =================
    async register(userData) {
      const data = await this.request("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(userData)
      });
      if (data.access_token) {
        this.setToken(data.access_token);
        this.setUser(data.user);
      }
      return data;
    },

    async login(email, password) {
      const data = await this.request("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password })
      });
      if (data.access_token) {
        this.setToken(data.access_token);
        this.setUser(data.user);
      }
      return data;
    },

    async getMe() {
      try {
        const user = await this.request("/api/auth/me");
        return this.setUser(user);
      } catch (e) {
        return this.getUser();
      }
    },

    async updateProfile(updates) {
      const user = await this.request("/api/auth/me", {
        method: "PUT",
        body: JSON.stringify(updates)
      });
      return this.setUser(user);
    },

    async updateAvatar(avatarUrl) {
      return await this.request("/api/auth/avatar", {
        method: "POST",
        body: JSON.stringify({ avatar_url: avatarUrl })
      });
    },

    // ================= TRIPS =================
    async getTrips(status = "all", search = "") {
      const params = new URLSearchParams();
      if (status && status !== "all") params.append("status", status);
      if (search) params.append("search", search);
      const query = params.toString() ? `?${params.toString()}` : "";
      return await this.request(`/api/trips${query}`);
    },

    async getTrip(tripId) {
      return await this.request(`/api/trips/${tripId}`);
    },

    async createTrip(tripData) {
      return await this.request("/api/trips", {
        method: "POST",
        body: JSON.stringify(tripData)
      });
    },

    async updateTrip(tripId, tripData) {
      return await this.request(`/api/trips/${tripId}`, {
        method: "PUT",
        body: JSON.stringify(tripData)
      });
    },

    async deleteTrip(tripId) {
      return await this.request(`/api/trips/${tripId}`, {
        method: "DELETE"
      });
    },

    // ================= ITINERARY =================
    async getItineraryStops(tripId = null) {
      const query = tripId ? `?trip_id=${tripId}` : "";
      return await this.request(`/api/itinerary/stops${query}`);
    },

    async createItineraryStop(stopData) {
      return await this.request("/api/itinerary/stops", {
        method: "POST",
        body: JSON.stringify(stopData)
      });
    },

    async deleteItineraryStop(stopId) {
      return await this.request(`/api/itinerary/stops/${stopId}`, {
        method: "DELETE"
      });
    },

    async getFullItinerary() {
      return await this.request("/api/itinerary/full");
    },

    async saveFullItinerary(itineraryData) {
      return await this.request("/api/itinerary/save-full", {
        method: "POST",
        body: JSON.stringify(itineraryData)
      });
    },

    // ================= ACTIVITIES =================
    async getActivities(params = {}) {
      const searchParams = new URLSearchParams();
      if (params.city && params.city !== "all") searchParams.append("city", params.city);
      if (params.category && params.category !== "all") searchParams.append("category", params.category);
      if (params.search) searchParams.append("search", params.search);
      if (params.sort) searchParams.append("sort", params.sort);
      const query = searchParams.toString() ? `?${searchParams.toString()}` : "";
      return await this.request(`/api/activities${query}`);
    },

    // ================= DASHBOARD =================
    async getDashboardStats() {
      return await this.request("/api/dashboard/stats");
    },

    // ================= UI HELPERS =================
    showToast(message, type = "success") {
      let toast = document.getElementById("toast");
      if (!toast) {
        toast = document.createElement("div");
        toast.id = "toast";
        toast.className = "toast";
        document.body.appendChild(toast);
      }

      toast.textContent = message;
      toast.classList.remove("error", "info", "success");
      if (type === "error") {
        toast.style.background = "linear-gradient(135deg, #e11d48, #be123c)";
      } else if (type === "info") {
        toast.style.background = "linear-gradient(135deg, #2563eb, #1d4ed8)";
      } else {
        toast.style.background = "linear-gradient(135deg, #10b981, #059669)";
      }

      toast.style.position = "fixed";
      toast.style.bottom = "24px";
      toast.style.right = "24px";
      toast.style.padding = "12px 20px";
      toast.style.color = "#ffffff";
      toast.style.borderRadius = "8px";
      toast.style.fontWeight = "600";
      toast.style.fontSize = "13px";
      toast.style.boxShadow = "0 10px 25px rgba(0,0,0,0.3)";
      toast.style.zIndex = "999999";
      toast.style.transition = "all 0.3s ease";
      toast.style.opacity = "1";
      toast.style.transform = "translateY(0)";
      toast.style.display = "block";

      setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateY(10px)";
        setTimeout(() => { toast.style.display = "none"; }, 300);
      }, 3000);
    },

    displayUser(user) {
      if (!user) user = this.getUser();
      if (!user) return;

      const fullName = user.fullName || `${user.firstName || ''} ${user.lastName || ''}`.trim() || "Travio Traveler";
      const firstName = user.firstName || fullName.split(" ")[0] || "Traveler";
      const email = user.email || "user@email.com";
      const location = [user.city, user.country].filter(Boolean).join(", ") || "Earth";
      const initials = ((user.firstName || "T").charAt(0) + (user.lastName || "T").charAt(0)).toUpperCase();

      document.querySelectorAll("[data-travio-name]").forEach(el => el.textContent = fullName);
      document.querySelectorAll("[data-travio-firstname]").forEach(el => el.textContent = firstName);
      document.querySelectorAll("[data-travio-email]").forEach(el => el.textContent = email);
      document.querySelectorAll("[data-travio-location]").forEach(el => el.textContent = location);

      const avatarEls = [
        document.getElementById("userProfile"),
        document.getElementById("profileLarge"),
        document.getElementById("avatar"),
        document.getElementById("smallAvatar"),
        document.getElementById("profileButton")
      ].filter(Boolean);

      avatarEls.forEach(el => {
        if (user.avatarUrl) {
          el.innerHTML = `<img src="${user.avatarUrl}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" alt="${fullName}">`;
        } else {
          el.textContent = initials;
        }
      });
    }
  };

  // Shared Routes
  const routes = {
    dashboard: "dashboard.html",
    create: "create-trip.html",
    trips: "my-trips.html",
    builder: "itinerary-builder.html",
    itinerary: "itinerary.html",
    cities: "dashboard.html#cities",
    activities: "activities.html",
    budget: "dashboard.html#budget",
    calendar: "calendar.html",
    shared: "dashboard.html#shared",
    settings: "user-profile.html",
    profile: "user-profile.html",
    login: "login.html",
    register: "register.html"
  };

  window.travioGo = function (page) {
    window.location.href = routes[page] || routes.dashboard;
  };

  window.openUserProfile = function () {
    window.location.href = routes.profile;
  };

  window.goToLogin = function () {
    window.location.href = routes.login;
  };

  window.goToRegister = function () {
    window.location.href = routes.register;
  };

  window.travioUser = function () {
    return TravioAPI.getUser();
  };

  window.travioDisplayUser = function () {
    TravioAPI.displayUser();
  };

  window.TravioAPI = TravioAPI;

  // Auto init on page load
  document.addEventListener("DOMContentLoaded", async function () {
    // Attempt to sync latest user details from backend
    try {
      if (TravioAPI.getToken()) {
        await TravioAPI.getMe();
      } else {
        // Provide demo user fallback if no token
        const existing = TravioAPI.getUser();
        if (!existing) {
          TravioAPI.setUser({
            firstName: "Travio",
            lastName: "Explorer",
            fullName: "Travio Explorer",
            email: "demo@travio.com",
            city: "Mumbai",
            country: "India",
            bio: "Passionate traveler exploring the world!"
          });
        }
      }
    } catch (e) {
      // Offline fallback
    }

    TravioAPI.displayUser();

    // Hook up generic navbar links
    const labels = {
      "Dashboard": "dashboard",
      "Create Trip": "create",
      "My Trips": "trips",
      "Itinerary Builder": "builder",
      "Itinerary View": "itinerary",
      "City Search": "cities",
      "Activities": "activities",
      "Budget": "budget",
      "Calendar": "calendar",
      "Shared Trip": "shared",
      "Settings": "settings"
    };

    document.querySelectorAll("a, button").forEach(el => {
      const text = (el.textContent || "").replace(/\s+/g, " ").trim();
      for (const [key, routeKey] of Object.entries(labels)) {
        if (text.includes(key) && el.tagName === "A" && el.getAttribute("href") === "#") {
          el.setAttribute("href", routes[routeKey]);
        }
      }
    });
  });
})(window);
