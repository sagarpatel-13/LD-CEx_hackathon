from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime

# ================= AUTH SCHEMAS =================
class UserRegister(BaseModel):
    email: str
    password: str
    first_name: Optional[str] = "Travio"
    last_name: Optional[str] = "Traveler"
    phone: Optional[str] = ""
    city: Optional[str] = ""
    country: Optional[str] = ""
    bio: Optional[str] = "Passionate traveler exploring the world!"
    avatar_url: Optional[str] = ""

class UserLogin(BaseModel):
    email: str
    password: str

class UserUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    city: Optional[str] = None
    country: Optional[str] = None
    bio: Optional[str] = None
    avatar_url: Optional[str] = None

class AvatarUpdate(BaseModel):
    avatar_url: str

class UserOut(BaseModel):
    id: int
    email: str
    first_name: str
    last_name: str
    full_name: Optional[str] = None
    phone: Optional[str] = ""
    city: Optional[str] = ""
    country: Optional[str] = ""
    bio: Optional[str] = ""
    avatar_url: Optional[str] = ""
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut

# ================= TRIP SCHEMAS =================
class TripCreate(BaseModel):
    name: str
    destination: str
    start_date: Optional[str] = ""
    end_date: Optional[str] = ""
    travellers: Optional[int] = 1
    budget: Optional[float] = 0.0
    spent: Optional[float] = 0.0
    trip_type: Optional[str] = "Adventure"
    status: Optional[str] = "upcoming"
    notes: Optional[str] = ""
    image_url: Optional[str] = ""

class TripUpdate(BaseModel):
    name: Optional[str] = None
    destination: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    travellers: Optional[int] = None
    budget: Optional[float] = None
    spent: Optional[float] = None
    trip_type: Optional[str] = None
    status: Optional[str] = None
    notes: Optional[str] = None
    image_url: Optional[str] = None

class TripOut(BaseModel):
    id: int
    user_id: int
    name: str
    destination: str
    start_date: Optional[str] = ""
    end_date: Optional[str] = ""
    travellers: int
    budget: float
    spent: float
    trip_type: str
    status: str
    notes: Optional[str] = ""
    image_url: Optional[str] = ""
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# ================= ITINERARY SCHEMAS =================
class ItineraryStopCreate(BaseModel):
    trip_id: Optional[int] = None
    day_number: Optional[int] = 1
    city: str
    country: Optional[str] = ""
    start_date: Optional[str] = ""
    end_date: Optional[str] = ""
    travel_mode: Optional[str] = "Flight"
    notes: Optional[str] = ""
    order_index: Optional[int] = 1
    image_url: Optional[str] = ""

class ItineraryStopOut(BaseModel):
    id: int
    trip_id: Optional[int] = None
    user_id: int
    day_number: int
    city: str
    country: Optional[str] = ""
    start_date: Optional[str] = ""
    end_date: Optional[str] = ""
    travel_mode: str
    notes: Optional[str] = ""
    order_index: int
    image_url: Optional[str] = ""

    class Config:
        from_attributes = True

class ItineraryActivityItem(BaseModel):
    activity: str
    expense: Optional[float] = 0.0
    category: Optional[str] = "Activity"

class FullItinerarySave(BaseModel):
    trip_id: Optional[int] = None
    destination_name: Optional[str] = "Paris"
    destination_country: Optional[str] = "France"
    budget: Optional[float] = 0.0
    day1: List[ItineraryActivityItem] = []
    day2: List[ItineraryActivityItem] = []

# ================= ACTIVITY SCHEMAS =================
class ActivityOut(BaseModel):
    id: int
    title: str
    city: str
    city_name: Optional[str] = ""
    category: str
    location: Optional[str] = ""
    description: Optional[str] = ""
    rating: float
    reviews: int
    price: float
    image_url: Optional[str] = ""
    is_featured: Optional[bool] = False

    class Config:
        from_attributes = True

# ================= DASHBOARD STATS =================
class DashboardStats(BaseModel):
    total_trips: int
    upcoming_trips: int
    completed_trips: int
    planning_trips: int
    countries_visited: int
    total_budget: float
    total_spent: float
