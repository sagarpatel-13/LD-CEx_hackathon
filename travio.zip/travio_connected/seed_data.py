from sqlalchemy.orm import Session
import models
from auth import hash_password

def seed_database(db: Session):
    # Check if demo user already exists
    demo_user = db.query(models.User).filter(models.User.email == "demo@travio.com").first()
    if not demo_user:
        demo_user = models.User(
            email="demo@travio.com",
            password_hash=hash_password("password123"),
            first_name="Travio",
            last_name="Explorer",
            phone="9876543210",
            city="Mumbai",
            country="India",
            bio="Passionate traveler exploring the world, cultures, and mountain trails!",
            avatar_url=""
        )
        db.add(demo_user)
        db.commit()
        db.refresh(demo_user)

    # Check if trips exist
    existing_trips = db.query(models.Trip).filter(models.Trip.user_id == demo_user.id).count()
    if existing_trips == 0:
        trips = [
            models.Trip(
                user_id=demo_user.id,
                name="Swiss Adventure",
                destination="Zurich, Switzerland",
                start_date="2026-09-12",
                end_date="2026-09-20",
                travellers=2,
                budget=85000.0,
                spent=0.0,
                trip_type="Adventure",
                status="upcoming",
                notes="Alpine hikes, scenic trains, and lake cruises.",
                image_url="https://images.unsplash.com/photo-1530789253388-582c481c54b0?auto=format&fit=crop&w=900&q=80"
            ),
            models.Trip(
                user_id=demo_user.id,
                name="Bali Escape",
                destination="Bali, Indonesia",
                start_date="2026-10-05",
                end_date="2026-10-11",
                travellers=4,
                budget=62000.0,
                spent=0.0,
                trip_type="Leisure",
                status="planning",
                notes="Beach clubs, temple tours, and rice terraces.",
                image_url="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80"
            ),
            models.Trip(
                user_id=demo_user.id,
                name="Japan Discovery",
                destination="Tokyo, Japan",
                start_date="2026-11-02",
                end_date="2026-11-12",
                travellers=3,
                budget=120000.0,
                spent=0.0,
                trip_type="Cultural",
                status="upcoming",
                notes="Exploring temples, modern tech, ramen spots and Kyoto bullet train.",
                image_url="https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=900&q=80"
            ),
            models.Trip(
                user_id=demo_user.id,
                name="Greek Getaway",
                destination="Santorini, Greece",
                start_date="2026-06-10",
                end_date="2026-06-16",
                travellers=2,
                budget=75000.0,
                spent=75000.0,
                trip_type="Relaxation",
                status="completed",
                notes="Sunset in Oia, Aegean yacht cruise, and Mediterranean cuisine.",
                image_url="https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=900&q=80"
            ),
            models.Trip(
                user_id=demo_user.id,
                name="Thailand Explorer",
                destination="Bangkok, Thailand",
                start_date="2026-03-18",
                end_date="2026-03-24",
                travellers=3,
                budget=54000.0,
                spent=54000.0,
                trip_type="Leisure",
                status="completed",
                notes="Floating markets, street food tours and Grand Palace.",
                image_url="https://images.unsplash.com/photo-1528181304800-259b08848526?auto=format&fit=crop&w=900&q=80"
            ),
            models.Trip(
                user_id=demo_user.id,
                name="Himalayan Escape",
                destination="Manali, India",
                start_date="2026-12-20",
                end_date="2026-12-26",
                travellers=5,
                budget=38000.0,
                spent=0.0,
                trip_type="Adventure",
                status="planning",
                notes="Snow activities, river rafting, and mountain bonfires.",
                image_url="https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=900&q=80"
            )
        ]
        db.add_all(trips)
        db.commit()

    # Seed Itinerary Stops
    existing_stops = db.query(models.ItineraryStop).filter(models.ItineraryStop.user_id == demo_user.id).count()
    if existing_stops == 0:
        stops = [
            models.ItineraryStop(
                user_id=demo_user.id,
                day_number=1,
                city="Paris",
                country="France",
                start_date="2026-06-15",
                end_date="2026-06-16",
                travel_mode="Flight",
                notes="Arrival, Eiffel Tower sunset & Seine cruise",
                order_index=1,
                image_url="https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=900&q=80"
            ),
            models.ItineraryStop(
                user_id=demo_user.id,
                day_number=2,
                city="Rome",
                country="Italy",
                start_date="2026-06-16",
                end_date="2026-06-18",
                travel_mode="Flight",
                notes="Colosseum, Vatican and authentic pasta tasting",
                order_index=2,
                image_url="https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=900&q=80"
            ),
            models.ItineraryStop(
                user_id=demo_user.id,
                day_number=3,
                city="Amsterdam",
                country="Netherlands",
                start_date="2026-06-19",
                end_date="2026-06-22",
                travel_mode="Train",
                notes="Canal boat tour, museum district and cycling",
                order_index=3,
                image_url="https://images.unsplash.com/photo-1534351590666-13e3e96b5017?auto=format&fit=crop&w=900&q=80"
            ),
            models.ItineraryStop(
                user_id=demo_user.id,
                day_number=4,
                city="Barcelona",
                country="Spain",
                start_date="2026-06-22",
                end_date="2026-06-25",
                travel_mode="Flight",
                notes="Sagrada Familia, Gothic Quarter & beach walks",
                order_index=4,
                image_url="https://images.unsplash.com/photo-1583422409516-2895a77efded?auto=format&fit=crop&w=900&q=80"
            )
        ]
        db.add_all(stops)
        db.commit()

    # Seed Itinerary Activities for Paris / Demo trip
    existing_itinerary_acts = db.query(models.ItineraryActivity).filter(models.ItineraryActivity.user_id == demo_user.id).count()
    if existing_itinerary_acts == 0:
        itinerary_activities = [
            models.ItineraryActivity(user_id=demo_user.id, day_number=1, activity_name="Visit Eiffel Tower", expense=2500.0, category="sightseeing", order_index=1),
            models.ItineraryActivity(user_id=demo_user.id, day_number=1, activity_name="Explore Louvre Museum", expense=1800.0, category="culture", order_index=2),
            models.ItineraryActivity(user_id=demo_user.id, day_number=1, activity_name="Seine River Cruise", expense=2200.0, category="leisure", order_index=3),
            models.ItineraryActivity(user_id=demo_user.id, day_number=2, activity_name="Visit Montmartre", expense=1500.0, category="sightseeing", order_index=1),
            models.ItineraryActivity(user_id=demo_user.id, day_number=2, activity_name="Local Food Tour", expense=2000.0, category="food", order_index=2),
            models.ItineraryActivity(user_id=demo_user.id, day_number=2, activity_name="Shopping", expense=1200.0, category="shopping", order_index=3),
        ]
        db.add_all(itinerary_activities)
        db.commit()

    # Seed Curated Global Activities
    existing_activities = db.query(models.Activity).count()
    if existing_activities == 0:
        curated_activities = [
            # Ahmedabad
            models.Activity(
                title="Adalaj Stepwell",
                city="ahmedabad",
                city_name="Ahmedabad",
                category="culture",
                location="Adalaj, Gujarat",
                description="Explore the stunning 15th-century Indo-Islamic stepwell architecture with intricate carvings.",
                rating=4.8,
                reviews=760,
                price=50.0,
                image_url="https://lp-cms-production.imgix.net/image_browser/Adalaj_Vav_G.jpg?auto=format&q=85",
                is_featured=True
            ),
            models.Activity(
                title="Sabarmati Riverfront Walk & Boating",
                city="ahmedabad",
                city_name="Ahmedabad",
                category="leisure",
                location="Sabarmati Riverfront, Ahmedabad",
                description="Enjoy sunset walks, peaceful river views, gardens and speed boating by the river.",
                rating=4.7,
                reviews=1240,
                price=150.0,
                image_url="https://images.unsplash.com/photo-1609137144822-4752c033878b?auto=format&fit=crop&w=800&q=80",
                is_featured=True
            ),
            models.Activity(
                title="Gandhi Ashram Heritage Tour",
                city="ahmedabad",
                city_name="Ahmedabad",
                category="culture",
                location="Sabarmati, Ahmedabad",
                description="Immerse yourself in history and peace at Mahatma Gandhi's historic headquarters.",
                rating=4.9,
                reviews=980,
                price=0.0,
                image_url="https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?auto=format&fit=crop&w=800&q=80",
                is_featured=False
            ),
            # Paris
            models.Activity(
                title="Eiffel Tower Summit & Champagne",
                city="paris",
                city_name="Paris",
                category="sightseeing",
                location="Champ de Mars, Paris",
                description="Witness panoramic views of Paris from the iconic tower summit with a sunset view.",
                rating=4.9,
                reviews=3400,
                price=2500.0,
                image_url="https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=900&q=80",
                is_featured=True
            ),
            models.Activity(
                title="Louvre Museum Guided Masterpieces",
                city="paris",
                city_name="Paris",
                category="culture",
                location="Rue de Rivoli, Paris",
                description="See the Mona Lisa, Venus de Milo, and world-renowned artistic treasures.",
                rating=4.8,
                reviews=2890,
                price=1800.0,
                image_url="https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&w=800&q=80",
                is_featured=True
            ),
            models.Activity(
                title="Seine River Illuminated Evening Cruise",
                city="paris",
                city_name="Paris",
                category="leisure",
                location="Pont de Bir-Hakeim, Paris",
                description="Glide through the heart of Paris witnessing monuments lit up against the night sky.",
                rating=4.7,
                reviews=1650,
                price=2200.0,
                image_url="https://images.unsplash.com/photo-1509439581779-6298f75bf6e5?auto=format&fit=crop&w=800&q=80",
                is_featured=False
            ),
            # Tokyo
            models.Activity(
                title="Shibuya Sky & Harajuku Culture",
                city="tokyo",
                city_name="Tokyo",
                category="adventure",
                location="Shibuya, Tokyo",
                description="360-degree observation deck over Tokyo's iconic scramble crossing followed by trendsetting fashion alleys.",
                rating=4.9,
                reviews=2100,
                price=1400.0,
                image_url="https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800&q=80",
                is_featured=True
            ),
            models.Activity(
                title="Mount Fuji & Lake Kawaguchi Day Trip",
                city="tokyo",
                city_name="Tokyo",
                category="adventure",
                location="Yamanashi, Japan",
                description="Breathtaking mountain views, traditional villages, and picturesque lake scenery.",
                rating=4.9,
                reviews=1870,
                price=4500.0,
                image_url="https://images.unsplash.com/photo-1490806843957-31f4c9a91c65?auto=format&fit=crop&w=800&q=80",
                is_featured=True
            ),
            # Bali
            models.Activity(
                title="Uluwatu Sunset Cliff & Kecak Fire Dance",
                city="bali",
                city_name="Bali",
                category="culture",
                location="Uluwatu, Bali",
                description="Witness dramatic clifftop ocean views and traditional Balinese fire dance at golden hour.",
                rating=4.8,
                reviews=2300,
                price=1100.0,
                image_url="https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=800&q=80",
                is_featured=True
            ),
            models.Activity(
                title="Nusa Penida Snorkeling & Manta Rays",
                city="bali",
                city_name="Bali",
                category="adventure",
                location="Nusa Penida, Bali",
                description="Swim with magnificent manta rays and explore crystal-clear turquoise lagoons.",
                rating=4.9,
                reviews=1560,
                price=3200.0,
                image_url="https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80",
                is_featured=True
            ),
            # Rome
            models.Activity(
                title="Colosseum & Roman Forum VIP Access",
                city="rome",
                city_name="Rome",
                category="culture",
                location="Piazza del Colosseo, Rome",
                description="Step inside gladiatorial history and walk the ancient heart of the Roman Empire.",
                rating=4.9,
                reviews=4100,
                price=2800.0,
                image_url="https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=900&q=80",
                is_featured=True
            ),
            # Jaipur
            models.Activity(
                title="Amber Fort Elephant & Palace Tour",
                city="jaipur",
                city_name="Jaipur",
                category="culture",
                location="Amer, Jaipur",
                description="Grand royal architecture, Sheesh Mahal mirror palace and majestic hilltop views.",
                rating=4.8,
                reviews=1920,
                price=600.0,
                image_url="https://images.unsplash.com/photo-1603287681856-960131c7d755?auto=format&fit=crop&w=800&q=80",
                is_featured=True
            ),
            # Manali
            models.Activity(
                title="Solang Valley Paragliding & Zipline",
                city="manali",
                city_name="Manali",
                category="adventure",
                location="Solang Valley, Manali",
                description="Soar high above snow-capped Himalayan peaks with expert pilots for an adrenaline thrill.",
                rating=4.9,
                reviews=1430,
                price=3000.0,
                image_url="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
                is_featured=True
            )
        ]
        db.add_all(curated_activities)
        db.commit()
