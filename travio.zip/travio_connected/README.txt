Travio Connected Travel Platform
==================================

Full-Stack Travel Planning Application with Python FastAPI & SQLite Backend.

Quick Start:
-----------
1. Start Backend & Web Server:
   Run: python main.py
   (Or double-click `start_server.bat`)

2. Open in Browser:
   http://127.0.0.1:8000/
   or http://127.0.0.1:8000/dashboard.html

3. Interactive API Documentation (Swagger UI):
   http://127.0.0.1:8000/docs

Default Demo Credentials:
------------------------
- Email:    demo@travio.com
- Password: password123

Features & Pages:
-----------------
- dashboard.html        : Interactive dashboard with live travel statistics & highlights
- create-trip.html      : Trip creation wizard with real-time preview & backend DB persistence
- my-trips.html         : Filterable trip manager (Upcoming, Planning, Completed) with search & delete
- itinerary-builder.html: Multi-city itinerary stop planner & day-by-day timeline generator
- itinerary.html        : Day-wise activity and expense tracker with dynamic budget breakdown
- activities.html       : Curated activity explorer with city filters, search & favorites
- calendar.html         : Monthly interactive travel calendar synced to your database trips
- user-profile.html     : Live profile management with photo avatar upload
- login.html            : JWT-secured user authentication
- register.html         : Account registration with city selector and photo upload
- database.db           : SQLite database automatically managed by SQLAlchemy ORM
