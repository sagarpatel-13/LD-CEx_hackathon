from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    first_name = Column(String(100), default="Travio")
    last_name = Column(String(100), default="Traveler")
    phone = Column(String(50), default="")
    city = Column(String(100), default="")
    country = Column(String(100), default="")
    bio = Column(Text, default="Passionate traveler exploring the world!")
    avatar_url = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    trips = relationship("Trip", back_populates="user", cascade="all, delete-orphan")
    itinerary_stops = relationship("ItineraryStop", back_populates="user", cascade="all, delete-orphan")
    itinerary_activities = relationship("ItineraryActivity", back_populates="user", cascade="all, delete-orphan")


class Trip(Base):
    __tablename__ = "trips"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(200), nullable=False)
    destination = Column(String(200), nullable=False)
    start_date = Column(String(50), default="")
    end_date = Column(String(50), default="")
    travellers = Column(Integer, default=1)
    budget = Column(Float, default=0.0)
    spent = Column(Float, default=0.0)
    trip_type = Column(String(50), default="Adventure")
    status = Column(String(50), default="upcoming")  # upcoming, planning, completed
    notes = Column(Text, default="")
    image_url = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="trips")
    stops = relationship("ItineraryStop", back_populates="trip", cascade="all, delete-orphan")
    activities = relationship("ItineraryActivity", back_populates="trip", cascade="all, delete-orphan")


class ItineraryStop(Base):
    __tablename__ = "itinerary_stops"

    id = Column(Integer, primary_key=True, index=True)
    trip_id = Column(Integer, ForeignKey("trips.id", ondelete="CASCADE"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    day_number = Column(Integer, default=1)
    city = Column(String(100), nullable=False)
    country = Column(String(100), default="")
    start_date = Column(String(50), default="")
    end_date = Column(String(50), default="")
    travel_mode = Column(String(50), default="Flight")
    notes = Column(Text, default="")
    order_index = Column(Integer, default=1)
    image_url = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    trip = relationship("Trip", back_populates="stops")
    user = relationship("User", back_populates="itinerary_stops")


class ItineraryActivity(Base):
    __tablename__ = "itinerary_activities"

    id = Column(Integer, primary_key=True, index=True)
    trip_id = Column(Integer, ForeignKey("trips.id", ondelete="CASCADE"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    day_number = Column(Integer, default=1)
    activity_name = Column(String(255), nullable=False)
    expense = Column(Float, default=0.0)
    category = Column(String(50), default="Activity")
    order_index = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)

    trip = relationship("Trip", back_populates="activities")
    user = relationship("User", back_populates="itinerary_activities")


class Activity(Base):
    __tablename__ = "activities"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    city = Column(String(100), nullable=False, index=True)
    city_name = Column(String(100), default="")
    category = Column(String(50), default="adventure", index=True)
    location = Column(String(255), default="")
    description = Column(Text, default="")
    rating = Column(Float, default=4.8)
    reviews = Column(Integer, default=100)
    price = Column(Float, default=0.0)
    image_url = Column(Text, default="")
    is_featured = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
