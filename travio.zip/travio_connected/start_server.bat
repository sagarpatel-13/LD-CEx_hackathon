@echo off
echo ===================================================
echo           Starting Travio Connected Backend
echo ===================================================
echo Server starting at: http://127.0.0.1:8000
echo API Documentation:  http://127.0.0.1:8000/docs
echo.
python main.py
pause
